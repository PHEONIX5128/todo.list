import { useState } from "react";
import { useTasks } from "@/hooks/use-tasks";
import { Header } from "@/components/header";
import { TaskFilter, FilterType } from "@/components/task-filter";
import { TaskCard } from "@/components/task-card";
import { TaskFormDialog } from "@/components/task-form-dialog";
import { DeleteTaskDialog } from "@/components/delete-task-dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { Task } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { toast } = useToast();
  const [currentFilter, setCurrentFilter] = useState<FilterType>("all");
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<number | null>(null);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);

  const {
    tasks,
    isLoading,
    createTask,
    updateTask,
    deleteTask,
    clearCompletedTasks,
    toggleTaskStatus,
  } = useTasks();

  // Filter tasks based on current filter
  const filteredTasks = tasks.filter((task) => {
    if (currentFilter === "all") return true;
    if (currentFilter === "active") return !task.completed;
    if (currentFilter === "completed") return task.completed;
    return true;
  });

  const hasCompletedTasks = tasks.some((task) => task.completed);

  const handleFilterChange = (filter: FilterType) => {
    setCurrentFilter(filter);
  };

  const handleCreateTask = (data: { title: string; description?: string }) => {
    createTask.mutate(
      {
        title: data.title,
        description: data.description || "",
        completed: false,
      },
      {
        onSuccess: () => {
          setShowNewTaskModal(false);
          toast({
            title: "Task created",
            description: "Your task has been created successfully.",
          });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to create task. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  const handleUpdateTask = (data: { title: string; description?: string }) => {
    if (!editingTask) return;

    updateTask.mutate(
      {
        id: editingTask.id,
        task: {
          title: data.title,
          description: data.description || "",
          completed: editingTask.completed,
        },
      },
      {
        onSuccess: () => {
          setShowNewTaskModal(false);
          setEditingTask(undefined);
          toast({
            title: "Task updated",
            description: "Your task has been updated successfully.",
          });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to update task. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  const handleDeleteTask = (id: number) => {
    setTaskToDelete(id);
    setShowDeleteModal(true);
  };

  const confirmDeleteTask = () => {
    if (taskToDelete === null) return;

    deleteTask.mutate(taskToDelete, {
      onSuccess: () => {
        setShowDeleteModal(false);
        setTaskToDelete(null);
        toast({
          title: "Task deleted",
          description: "Your task has been deleted successfully.",
        });
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to delete task. Please try again.",
          variant: "destructive",
        });
      },
    });
  };

  const handleClearCompleted = () => {
    clearCompletedTasks.mutate(undefined, {
      onSuccess: (data) => {
        toast({
          title: "Tasks cleared",
          description: `Successfully cleared ${data.count} completed ${data.count === 1 ? "task" : "tasks"}.`,
        });
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to clear completed tasks. Please try again.",
          variant: "destructive",
        });
      },
    });
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setShowNewTaskModal(true);
  };

  const handleToggleTaskStatus = (id: number, currentStatus: boolean) => {
    toggleTaskStatus(id, currentStatus);
  };

  const handleNewTask = () => {
    setEditingTask(undefined);
    setShowNewTaskModal(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header onNewTask={handleNewTask} />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold mb-1">Task Manager</h2>
            <p className="text-muted-foreground">Stay organized, one task at a time</p>
          </div>
        </div>
        
        <TaskFilter
          currentFilter={currentFilter}
          onFilterChange={handleFilterChange}
          onClearCompleted={handleClearCompleted}
          hasCompletedTasks={hasCompletedTasks}
        />
        
        <div className="space-y-4">
          {isLoading && (
            <div className="space-y-4">
              <Skeleton className="h-24 w-full rounded-md" />
              <Skeleton className="h-24 w-full rounded-md" />
              <Skeleton className="h-24 w-full rounded-md" />
            </div>
          )}
          
          {!isLoading && filteredTasks.length === 0 && (
            <EmptyState filterType={currentFilter} onNewTask={handleNewTask} />
          )}
          
          {!isLoading && filteredTasks.length > 0 && currentFilter === "all" && (
            <>
              {/* Active tasks */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-4 text-primary">Active Tasks</h3>
                <div className="space-y-4">
                  {filteredTasks
                    .filter(task => !task.completed)
                    .map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleStatus={handleToggleTaskStatus}
                        onEdit={handleEditTask}
                        onDelete={handleDeleteTask}
                      />
                    ))}
                  {filteredTasks.filter(task => !task.completed).length === 0 && (
                    <p className="text-muted-foreground italic py-4">No active tasks. All done!</p>
                  )}
                </div>
              </div>
              
              {/* Completed tasks */}
              <div>
                <h3 className="text-lg font-semibold mb-4 text-primary">Completed Tasks</h3>
                <div className="space-y-4">
                  {filteredTasks
                    .filter(task => task.completed)
                    .map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleStatus={handleToggleTaskStatus}
                        onEdit={handleEditTask}
                        onDelete={handleDeleteTask}
                      />
                    ))}
                  {filteredTasks.filter(task => task.completed).length === 0 && (
                    <p className="text-muted-foreground italic py-4">No tasks completed yet. Go to Active tasks to complete some!</p>
                  )}
                </div>
              </div>
            </>
          )}
          
          {!isLoading && filteredTasks.length > 0 && currentFilter !== "all" && 
            filteredTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onToggleStatus={handleToggleTaskStatus}
                onEdit={handleEditTask}
                onDelete={handleDeleteTask}
              />
            ))
          }
        </div>
      </main>
      
      <TaskFormDialog
        open={showNewTaskModal}
        onOpenChange={setShowNewTaskModal}
        onSubmit={editingTask ? handleUpdateTask : handleCreateTask}
        editingTask={editingTask}
        isSubmitting={editingTask ? updateTask.isPending : createTask.isPending}
      />
      
      <DeleteTaskDialog
        open={showDeleteModal}
        onOpenChange={setShowDeleteModal}
        onConfirm={confirmDeleteTask}
        isDeleting={deleteTask.isPending}
      />
    </div>
  );
}
