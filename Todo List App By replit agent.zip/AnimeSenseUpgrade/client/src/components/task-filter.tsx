import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type FilterType = "all" | "active" | "completed";

interface TaskFilterProps {
  currentFilter: FilterType;
  onFilterChange: (filter: FilterType) => void;
  onClearCompleted: () => void;
  hasCompletedTasks: boolean;
}

export function TaskFilter({
  currentFilter,
  onFilterChange,
  onClearCompleted,
  hasCompletedTasks,
}: TaskFilterProps) {
  return (
    <div className="flex flex-wrap gap-2 mb-6">
      <Button
        variant="outline"
        onClick={() => onFilterChange("all")}
        className={cn(
          "px-4 py-2 rounded-md text-sm font-medium transition-colors",
          currentFilter === "all" && "bg-primary text-primary-foreground hover:bg-primary/90"
        )}
      >
        All
      </Button>
      
      <Button
        variant="outline"
        onClick={() => onFilterChange("active")}
        className={cn(
          "px-4 py-2 rounded-md text-sm font-medium transition-colors",
          currentFilter === "active" && "bg-primary text-primary-foreground hover:bg-primary/90"
        )}
      >
        Active
      </Button>
      
      <Button
        variant="outline"
        onClick={() => onFilterChange("completed")}
        className={cn(
          "px-4 py-2 rounded-md text-sm font-medium transition-colors",
          currentFilter === "completed" && "bg-primary text-primary-foreground hover:bg-primary/90"
        )}
      >
        Completed
      </Button>
      
      <div className="ml-auto">
        <Button
          variant="outline"
          onClick={onClearCompleted}
          disabled={!hasCompletedTasks}
          className="px-4 py-2 bg-background hover:bg-secondary text-foreground rounded-md text-sm font-medium transition-colors"
        >
          Clear Completed
        </Button>
      </div>
    </div>
  );
}
