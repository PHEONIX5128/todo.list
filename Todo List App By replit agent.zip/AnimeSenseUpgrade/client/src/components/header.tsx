import { PlusCircle, Moon, Sun, CheckSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "../components/theme-provider";

interface HeaderProps {
  onNewTask: () => void;
}

export function Header({ onNewTask }: HeaderProps) {
  const { theme, setTheme } = useTheme();
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
    document.documentElement.classList.toggle("dark");
  };

  return (
    <header className="bg-background border-b border-border">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <CheckSquare className="h-8 w-8" />
          <h1 className="text-xl font-bold tracking-tight">Task Manager</h1>
        </div>
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Button 
            onClick={onNewTask}
            className="px-4 py-2 bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <PlusCircle className="h-4 w-4 mr-2" />
            New Task
          </Button>
        </div>
      </div>
    </header>
  );
}
