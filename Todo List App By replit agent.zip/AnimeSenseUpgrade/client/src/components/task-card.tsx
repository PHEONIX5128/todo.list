import { useState } from "react";
import { Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Task } from "@shared/schema";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface TaskCardProps {
  task: Task;
  onToggleStatus: (id: number, currentStatus: boolean) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
}

export function TaskCard({ task, onToggleStatus, onEdit, onDelete }: TaskCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  
  const formattedDate = format(new Date(task.createdAt), 'MMM d, yyyy');

  return (
    <div 
      className={cn(
        "task-card bg-card rounded-md shadow-md border border-border p-4 transition-all duration-200 hover:-translate-y-1",
        task.completed && "bg-muted/50 border-dashed"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-start gap-3">
        <Checkbox 
          checked={task.completed}
          onCheckedChange={() => onToggleStatus(task.id, task.completed)}
          className={cn(
            "mt-1 flex-shrink-0 w-5 h-5 rounded-full transition-colors",
            task.completed && "bg-primary border-primary"
          )}
        />
        
        <div className="flex-grow">
          <div className="flex items-start justify-between">
            <h3 
              className={cn(
                "font-medium text-foreground leading-tight",
                task.completed && "line-through opacity-70"
              )}
            >
              {task.title}
            </h3>
            
            <div className={cn("flex space-x-1 ml-2", !isHovered && "opacity-0", "transition-opacity duration-200")}>
              <Button 
                onClick={() => onEdit(task)} 
                variant="ghost" 
                size="icon" 
                className="p-1 hover:text-foreground transition-colors rounded-full hover:bg-accent"
              >
                <Edit className="h-4 w-4" />
                <span className="sr-only">Edit task</span>
              </Button>
              
              <Button 
                onClick={() => onDelete(task.id)} 
                variant="ghost" 
                size="icon" 
                className="p-1 hover:text-destructive transition-colors rounded-full hover:bg-accent"
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete task</span>
              </Button>
            </div>
          </div>
          
          {task.description && (
            <p 
              className={cn(
                "mt-1 text-sm text-muted-foreground font-mono",
                task.completed && "line-through opacity-70"
              )}
            >
              {task.description}
            </p>
          )}
          
          <div className="mt-3 flex items-center text-xs text-muted-foreground">
            <span>{formattedDate}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
