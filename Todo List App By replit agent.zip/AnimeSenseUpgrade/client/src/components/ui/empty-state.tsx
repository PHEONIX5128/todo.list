import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FilterType } from "@/components/task-filter";

interface EmptyStateProps {
  filterType: FilterType;
  onNewTask: () => void;
}

export function EmptyState({ filterType, onNewTask }: EmptyStateProps) {
  let message = "";
  
  switch (filterType) {
    case "all":
      message = "Your task list is empty. Create a new task to get started.";
      break;
    case "active":
      message = "No active tasks found. All your tasks are completed!";
      break;
    case "completed":
      message = "No tasks completed yet. Go to Active tasks to complete some!";
      break;
  }

  return (
    <div className="flex flex-col items-center justify-center py-12 animate-in fade-in duration-300">
      <div className="w-64 h-48 mb-6">
        <svg 
          viewBox="0 0 400 300" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          <path d="M200 250C255.228 250 300 205.228 300 150C300 94.7715 255.228 50 200 50C144.772 50 100 94.7715 100 150C100 205.228 144.772 250 200 250Z" className="fill-muted/50" />
          <path d="M185 180C185 180 195 190 215 180" className="stroke-foreground" strokeWidth="3" strokeLinecap="round"/>
          <path d="M160 130C166.627 130 172 124.627 172 118C172 111.373 166.627 106 160 106C153.373 106 148 111.373 148 118C148 124.627 153.373 130 160 130Z" className="fill-background stroke-foreground" strokeWidth="2"/>
          <path d="M240 130C246.627 130 252 124.627 252 118C252 111.373 246.627 106 240 106C233.373 106 228 111.373 228 118C228 124.627 233.373 130 240 130Z" className="fill-background stroke-foreground" strokeWidth="2"/>
          <path d="M165 118H155" className="stroke-foreground" strokeWidth="2"/>
          <path d="M245 118H235" className="stroke-foreground" strokeWidth="2"/>
          <path d="M160 116.5V119.5" className="stroke-foreground" strokeWidth="2"/>
          <path d="M240 116.5V119.5" className="stroke-foreground" strokeWidth="2"/>
          <path d="M100 150L80 110M300 150L320 110" className="stroke-foreground" strokeWidth="2" strokeLinecap="round"/>
          <path d="M130 210L110 250M270 210L290 250" className="stroke-foreground" strokeWidth="2" strokeLinecap="round"/>
          <path d="M180 70H220" className="stroke-foreground" strokeWidth="3" strokeLinecap="round"/>
          <path d="M180 220C180 220 190 230 200 230C210 230 220 220 220 220" className="stroke-foreground" strokeWidth="2" strokeLinecap="round"/>
          <path d="M140 80L120 60M260 80L280 60" className="stroke-foreground" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      </div>
      <h3 className="text-xl font-semibold mb-2">No tasks available</h3>
      <p className="text-muted-foreground text-center max-w-md mb-6">{message}</p>
      <Button
        onClick={onNewTask}
        className="bg-primary hover:bg-primary/90 text-primary-foreground"
      >
        <PlusCircle className="mr-2 h-4 w-4" />
        Create First Task
      </Button>
    </div>
  );
}
